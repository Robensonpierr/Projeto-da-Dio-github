public class Cao extends Mamifero {
	
	private static final long serialversionUID = 1L;
	private static final String latidos = null;
	
	public String soar() {
		return  latidos;
	}
	public Cao (String nome, int idade, String dono) {
		super(nome, idade, dono);
		this.especie = "Cachorro";
	
	}
	

}
