public  class Gato extends Mamifero {
	
private static final long serviralversionUID = 1L;	

public String soar() {
	return "faz Miados";
}
public Gato(String nome, int idade, String dono ) {
	super(nome, idade, dono);
	this.especie = "Gato si�mes";
}
}
