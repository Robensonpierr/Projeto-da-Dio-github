public class cavalo extends Mamifero {

private static final long serialversionUID=1L;

public String soar() {
	return "faz relinchos";
}
public cavalo(String nome, int idade, String dono) {
	super(nome, idade, dono);
	this.especie = "Cavalo";
}
 
}
