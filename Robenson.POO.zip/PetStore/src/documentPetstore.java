import java.awt.Component;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FilterInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class documentPetstore {
	private static final String inputStream = null;
	private Object mamiferos;
	private leao Leao;
	
	public documentPetstore() {
		this.mamiferos = new ArrayList<Mamifero>();
		
	}
	public String[] levalores (String [] dadosIn) {
		String [] dadosOut = new String [dadosIn.length];
		
		for (int i = 0; i < dadosIn.length; i++)
			dadosOut[i] = JOptionPane.showInputDialog("Entre com " + dadosIn[i] + ":");
		return dadosOut;
	}
	public Gato leGato() {
		
		String [] valores = new String [3];
		String [] nomeVal = {"Nome", "Idade", "Dono"};
		valores = levalores(nomeVal);
		
		int idade = this.retornaInteiro(valores[1]);
		
		Gato Gato = new Gato (valores[0], idade, valores[2]);
		
		return Gato;
	}
	
public leao leLeao() {
		
		String [] valores = new String [3];
		String [] nomeVal = {"Nome", "Idade", "Dono"};
		valores = levalores(nomeVal);
		
		int idade = this.retornaInteiro(valores[1]);
		
		leao Leao = new leao (valores[0], idade, valores[2]);
		
		return Leao;
	}

public cavalo leCavalo() {
	
	String [] valores = new String [3];
	String [] nomeVal = {"Nome", "Idade", "Dono"};
	valores = levalores(nomeVal);
	
	int idade = this.retornaInteiro(valores[1]);
	
	cavalo Cavalo = new cavalo (valores[0], idade, valores[2]);
	
	return Cavalo;
}	

	public Cao leCao() {
		String [] valores = new String [3];
		String [] nomeVal = {"Nome", "Idade", "Dono"};
		valores = levalores (nomeVal);
		
		int idade = this.retornaInteiro(valores[1]);
		
		Cao Cao = new Cao (valores[0], idade, valores[2]);
		return Cao;
		
	}
	private boolean intValido(String s) {
		try {
			Integer.parseInt(s);
			return true;
		}catch (NumberFormatException e) {
			return false;
		}
		
	}
	public int retornaInteiro(String entrada) {
		int numInt;
		
		
		while (!this.intValido(entrada)) {
			entrada = JOptionPane.showInputDialog(null, "valor incorreto!\n\nDigite um n�mero inteiro.");
			
		}
		return Integer.parseInt(entrada);
	}
	
	
	public void salvaMamiferos (Object mamiferos2 ) {
		ObjectOutputStream outputStream = null;
		try {
			outputStream = new ObjectOutputStream
					(new FileOutputStream("c:\\temp\\petstore.dados"));
			for (int i=0; i < ((ArrayList<Mamifero>) mamiferos).size(); i++)
				outputStream.writeObject(((ArrayList<Mamifero>) mamiferos).get(i));
			
		}catch (FileNotFoundException ex) {
			ex.printStackTrace();
		}catch (IOException ex) {
			ex.printStackTrace();
		}finally {
			try {
				if (outputStream != null) {
					outputStream.flush();
					outputStream.close();
				}
			}catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}
	@SuppressWarnings("finally")
	public ArrayList<Mamifero> recuperaMamiferos () throws FileNotFoundException{
		ArrayList<Mamifero> mamiferosTemp = new ArrayList<Mamifero> ();
		
		ObjectInputStream inputStream = null;
		
		
		try {
			inputStream = new ObjectInputStream
					(new FileInputStream("c:\\temp\\petStore.dados"));
			Object obj = null;
			while ((obj = inputStream.readObject()) != null) {
				if (obj instanceof Mamifero) {
					mamiferosTemp.add( (Mamifero)obj);
				}
			}
			
		}catch (EOFException ex) {
		System.out.println("Fim de arquivo.");
	} catch (FileNotFoundException ex) {
		ex.printStackTrace();
	}finally {
		try {
			if (inputStream != null) {
				inputStream.close();
			}
		}catch (final IOException ex) {
			ex.printStackTrace();
		}
		return mamiferosTemp;
	}
}	

public void menuPetStore() throws FileNotFoundException {
	String menu = "";
	String entrada;
	int    opc1, opc2, opc3, opc4;
	do {
		menu = "Controle PetStore\n"+
				"Op��es:\n" +
				"1. Entrar Mam�feros\n"+
				"2. Exibir Mam�feros\n"+
				"3. Limpar Mam�feros\n"+
				"4. Gravar Mam�feros\n"+
				"5. Recuperar Mam�feros\n"+
				"9. Sair";
		entrada = JOptionPane.showInputDialog(menu + "\n\n");
		opc1 = this.retornaInteiro(entrada);
		
		switch (opc1) {
		case 1:
			menu = "Entrada de Animais Mam�fero\n" +
					"Op��es:\n"+
					"1. C�o\n" +
					"2. Gato\n"+
					"3. Le�o\n"+
					"4. Cavalo\n";
			
			entrada = JOptionPane.showInputDialog(menu + "\n\n");
			opc2 = this.retornaInteiro(entrada);
			
			
			switch (opc2) {
			case 1: ((ArrayList<Mamifero>) mamiferos).add((Mamifero)leCao());
			break;
		case 2:
			if (((ArrayList<Mamifero>) mamiferos).size()== 0) {
				JOptionPane.showMessageDialog(null, "Entre com mam�feros..." );
				break;
			}
			String dados = "";
			for (int i=0; i <((ArrayList<Mamifero>) mamiferos).size(); i++) {
				dados += ((ArrayList<Mamifero>) mamiferos).get(i).toString() + "-------------\n";
				
			}
			JOptionPane.showMessageDialog(null,dados);
			break;
		case 3:
			if (((ArrayList<Mamifero>) mamiferos).size()== 0) {
				JOptionPane.showMessageDialog(null,"Entre com mam�feros .....");
				break;
			}
			((ArrayList<Mamifero>) mamiferos).clear();
			JOptionPane.showMessageDialog(null,"Dados Limpos com sucesso!");
			break;
		case 4:
			if(((ArrayList<Mamifero>) mamiferos).size()== 0 ) {
				JOptionPane.showMessageDialog(null," Entre com mam�feros");
				break;
			}
			salvaMamiferos(mamiferos);
			JOptionPane.showMessageDialog(null," Dados Salvos com sucesso!");
			break;
		case 5:
			mamiferos = recuperaMamiferos();
			if(((ArrayList<Mamifero>) mamiferos).size()== 0) {
				
			}
			JOptionPane.showMessageDialog(null, "Sem dados para apresentar.");
				break;
			}
			JOptionPane.showMessageDialog(null, "Dados recuperado com sucesso");
		case 9:
			JOptionPane.showMessageDialog(null, "l'aplication de PetStore termine i�i!");
			break;
		}
			
	} while (opc1!= 9);
		
}
public static void main(String[] args) throws FileNotFoundException {
	documentPetstore pet = new documentPetstore();
	pet.menuPetStore();
	
	}
}
